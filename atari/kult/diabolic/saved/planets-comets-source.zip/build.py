#!/usr/bin/env python3
"""Build a native Kult space variant, retaining the original RLE loader."""
import hashlib, json, math, os, random, struct, subprocess, sys
from pathlib import Path
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'editor'))
from assets import project,rle,word
from recover import kult

def packed(im):
    return bytes(sum(im.getpixel((x+i,y))<<(6-i*2) for i in range(4)) for y in range(im.height) for x in range(0,im.width,4))

def ship(frame):
    # Native ANTIC F is 40 hires pixels wide, not the web's 20 colour pairs.
    im=Image.new('1',(40,16));d=ImageDraw.Draw(im)
    d.polygon([(4,1),(15,3),(23,5),(36,0),(32,5),(24,8),(10,6)],fill=0,outline=1)
    d.polygon([(4,14),(15,12),(23,10),(36,15),(32,10),(24,7),(10,9)],fill=0,outline=1)
    d.polygon([(9,6),(17,4),(26,6),(38,8),(26,10),(17,11),(9,9),(12,8)],fill=1)
    d.line([(14,7),(25,7),(32,8)],fill=0)
    d.line([(14,9),(23,9)],fill=0)
    d.line([(1+frame%3,6),(8,6)],fill=1)
    d.line([(2+frame%2,9),(8,9)],fill=1)
    return im

def ship_bytes(im):
    return bytes(sum(int(im.getpixel((x+i,y)))<<(7-i) for i in range(8)) for y in range(16) for x in range(0,40,8))

def package(p,ram):
    # Keep a literal prefix in the retired tile bank: compressing empty space too
    # aggressively lets the in-place decoder overwrite its unread input.
    streams=[bytearray(),bytearray()];phase=0;old=p['banks']['ram']
    for block in p['blocks']:
        a=block['start'];data=bytearray(block['data'])
        for i in range(len(data)):
            if ram[a+i]!=old[a+i]:data[i]=ram[a+i]
        streams[phase]+=rle(struct.pack('<HH',a,len(data)))
        streams[phase]+=(b''.join(bytes([0xbf,v,1]) if v in (0xbf,0xcf) else bytes([v]) for v in data[:6144])+rle(data[6144:]) if a==0x2400 else rle(data))
        if a==0xbb00:
            streams[0]+=rle(bytes(4));phase=1
    streams[1]+=rle(struct.pack('<HH',0x7fee,0xffff))
    result=bytearray(p['original'])
    for base,end,encoded in zip((0x2b00,0x8000),(0x7fee,0xb300),streams):
        assert len(encoded)<=end-base,(hex(base),len(encoded),end-base)
        offset=6+base-0x2b00;result[offset:offset+len(encoded)]=encoded
    replay,_,_,_=kult(result)
    for b in p['blocks']:
        a=b['start'];n=b['size']
        if a not in (0xd301,0xbb00):assert replay[a:a+n]==ram[a:a+n],hex(a)
    return bytes(result)

def saturn():
    """32 unstretched PM pixels across: twice the previous horizontal detail."""
    im=Image.new('1',(32,56))
    def rings(front):
        for radius in (1.0,.84):
            for step in range(720):
                t=step*math.tau/720
                if (math.sin(t)>=0)!=front:continue
                x=15.5+15.1*radius*math.cos(t)
                y=27+6*radius*math.sin(t)-10*radius*math.cos(t)
                im.putpixel((round(x),round(y)),1)
    rings(False)
    bayer=((0,8,2,10),(12,4,14,6),(3,11,1,9),(15,7,13,5))
    for y in range(56):
        for x in range(32):
            dx=(x-15.5)/9.5;dy=(y-27)/18
            if dx*dx+dy*dy<=1:
                z=math.sqrt(max(0,1-dx*dx-dy*dy))
                light=max(.13,min(.98,.42+.52*z-.38*dx-.16*dy))
                bands=.09*math.sin(y*1.45+dx*.8)+.05*math.sin(y*.52)
                im.putpixel((x,y),int(light+bands>(bayer[y%4][x%4]+.5)/16))
    # Near-side ring gap and two fine arcs cross in front of the globe.
    for step in range(360):
        t=step*math.pi/360
        x=round(15.5+15.1*.92*math.cos(t));y=round(27+6*.92*math.sin(t)-10*.92*math.cos(t))
        im.putpixel((x,y),0)
    rings(True)
    return im

def scenery(ram,rng):
    # Points at irregular heights: avoid the old repeating vertical grid.
    for y in (64,128,147,171):
        ram[0x3400+y]=1<<rng.randrange(8)
    # Four independent missile lanes add widely separated, moving star depths.
    for lane,ys in enumerate(((69,101,137,173),(81,113,151),(63,91,127,163),(75,105,141,169))):
        for y in ys:ram[0x3300+y]|=1<<(lane*2)
    # Bright comet, nucleus at lower left, split tapering tail up and right.
    comet=Image.new('1',(8,18));d=ImageDraw.Draw(comet)
    d.line([(1,13),(7,0)],fill=1)
    d.line([(2,13),(7,5)],fill=1)
    d.line([(2,14),(7,10)],fill=1)
    d.ellipse((0,12,2,16),fill=1)
    for y in range(18):
        ram[0x3500+143+y]=sum(int(comet.getpixel((x,y)))<<(7-x) for x in range(8))
    planet=saturn()
    for y in range(56):
        for x in range(32):
            if planet.getpixel((x,y)):ram[0x3400+(x//8)*256+68+y]|=0x80>>(x%8)
    # Per-scanline luminance ramps for all four hardware players. No new hues.
    shades=[]
    for lane,peak in enumerate((6,12,8,4)):
        line=[]
        for y in range(64):
            falloff=int(abs(y-25)/12)*2
            shade=max(2,peak-falloff)
            ram[0x3800+lane*64+y]=shade;line.append(shade)
        shades.append(line)
    preview=Image.new('RGB',(224,92))
    planet_preview=Image.new('RGB',(64,56))
    for y in range(56):
        for x in range(32):
            v=round(shades[x//8][y]/14*255) if planet.getpixel((x,y)) else 0
            planet_preview.putpixel((x*2,y),(v,v,v));planet_preview.putpixel((x*2+1,y),(v,v,v))
    comet_preview=comet.resize((32,18),Image.Resampling.NEAREST).convert('RGB')
    preview.paste(planet_preview,(16,16));preview.paste(comet_preview,(130,44))
    preview.resize((672,276),Image.Resampling.NEAREST).save(ROOT/'scenery.png')

def main():
    p=project('kult');old=p['banks']['ram'];ram=bytearray(old)
    # Retire all building tiles, use the first sixteen slots for near stars,
    # and reuse the remainder for PM DMA and the small 6502 extension.
    ram[0x2400:0x4400]=bytes(0x2000)
    rng=random.Random(0xD1AB)
    for tile in range(1,16):
        im=Image.new('P',(8,16))
        if tile%3:
            x,y=rng.randrange(7),rng.randrange(16)
            im.putpixel((x,y),1)
            if tile%5==0:im.putpixel((x+1,y),1)
        ram[0x2400+tile*32:0x2420+tile*32]=packed(im)
    scenery(ram,rng)
    frames=[]
    for f in range(4):
        im=ship(f);frames.append(im)
        base=word(old,0x7450+f*2)
        for shift in range(4):
            aligned=Image.new('1',(40,16));aligned.paste(im,(shift*2,0))
            ram[base+shift*80:base+(shift+1)*80]=ship_bytes(aligned)
    subprocess.run([os.environ.get('MADS','mads'),str(ROOT/'space.asm'),'-o:'+str(ROOT/'space.bin'),'-l:'+str(ROOT/'space.lst')],check=True,stdout=subprocess.PIPE)
    code=(ROOT/'space.bin').read_bytes();ram[0x4000:0x4000+len(code)]=code
    patches={
        0xF746:('20d6e9','200040'), # graphics initialization
        0xF834:('2008f9','200340'), # per-game-frame parallax
        0xC41B:('adf1c3','200640'), # disable hardware scenery in menus
        0xE843:('2005e9','200940'), # replace building tile selection
        0xF764:('73','0c'),        # multiplex planet in its raster band
        0xF769:('ea','40'),
        0xF75F:('21','3d'),        # enable single-line player DMA
        0xF975:('c900','29aa'),    # pixel 01 stars cannot cause collisions
    }
    for at,(expected,new) in patches.items():
        assert old[at:at+len(bytes.fromhex(expected))]==bytes.fromhex(expected),hex(at)
        ram[at:at+len(bytes.fromhex(new))]=bytes.fromhex(new)
    out=package(p,ram);(ROOT/'kult-diabolic.xex').write_bytes(out)
    preview=Image.new('1',(164,20))
    for f,im in enumerate(frames):preview.paste(im,(f*41,2))
    preview.resize((656,80),Image.Resampling.NEAREST).convert('RGB').save(ROOT/'ship.png')
    manifest={'original_sha256':hashlib.sha256(p['original']).hexdigest(),'output_sha256':hashlib.sha256(out).hexdigest(),'runtime_changed_bytes':sum(a!=b for a,b in zip(old,ram)),'patches':{f'{a:04X}':{'before':x,'after':y} for a,(x,y) in patches.items()},'cpu_depacker_verified':True}
    (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('Built',ROOT/'kult-diabolic.xex','with verified original-loader replay.')
if __name__=='__main__':main()
