#!/usr/bin/env sh
set -eu
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "$script_dir/../../babajaga/run-emulator.sh" "$script_dir/kult-diabolic.xex" "$@"
