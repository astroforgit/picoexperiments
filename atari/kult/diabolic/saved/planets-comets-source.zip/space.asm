; Native 6502 additions in the retired building tile bank.
; Entry jump table is used by build.py; no ROM or VBXE required.
    opt h-
    org $4000
    jmp Init
    jmp Step
    jmp Menu
    jmp Tile
    jmp Raster
Init
    jsr $E9D6
    lda #$DF              ; DLI just before PM scanline 68, in both buffers
    sta $606D
    sta $622F
    lda #$30
    sta $D407              ; single-line PM graphics at $3400-$37FF
    lda #3
    sta $D01D
    lda #0
    sta $D01B              ; OR monochrome PM layers with hires playfield
    lda #0
    sta Clock
    sta $D008
    sta $D00C
    sta $02C8
    lda #1
    sta $D009
    sta $D00A
    sta $D00B
    lda #$04
    sta $02C0              ; original-style monochrome, distant stars
    lda #$0A
    sta $02C1              ; bright comet
    lda #$06
    sta $02C2
    lda #$06
    sta $02C3              ; dark grey planet
    ; Leave Kult's original playfield colours untouched.
    lda #190
    sta FarX
    lda #182
    sta MidX
    lda #142
    sta PlanetX
    ldx #3
SeedStars
    lda StartX,x
    sta StarX,x
    dex
    bpl SeedStars
    jsr Position
    rts
Step
    inc Clock
    dec MidX
    lda MidX
    cmp #48
    bcs Slow
    lda #208
    sta MidX
Slow
    lda Clock
    and #3
    bne Planet
    dec FarX
    lda FarX
    cmp #48
    bcs Planet
    lda #208
    sta FarX
Planet
    lda Clock
    and #15
    bne Draw
    dec PlanetX
    lda PlanetX
    cmp #20
    bcs Draw
    lda #208
    sta PlanetX
Draw
    ldx #3
MoveStars
    lda Clock
    and RateMask,x
    bne NextStar
    dec StarX,x
    lda StarX,x
    cmp #58
    bcs NextStar
    lda #190
    sta StarX,x
NextStar
    dex
    bpl MoveStars
    jsr Position
    jmp $F908              ; original buffer swap and sprite restoration
Position
    ldx #3
StarPositions
    lda StarX,x
    sta $D004,x
    dex
    bpl StarPositions
    lda FarX
    sta $D000
    lda MidX
    sta $D001
    lda PlanetX
    sta $D002
    clc
    adc #16
    sta $D003
    rts
Menu
    lda #0
    sta $D01D
    sta $D000
    sta $D001
    sta $D002
    sta $D003
    sta $D004
    sta $D005
    sta $D006
    sta $D007
    lda $C3F1              ; displaced instruction
    rts
Tile
    ; Mix row, section and column, independent of the old building map.
    tya
    asl
    asl
    eor $4E7A
    eor $4E79
    and #15
    jmp $E905
Raster
    pha
    lda $D40B
    cmp #64
    bcc PlanetRaster
    pla
    jmp $EA73             ; preserve original frame/buffer/sound DLI
PlanetRaster
    txa
    pha
    lda #0
    sta $D008
    sta $D009
    sta $D00A
    sta $D00B
    lda PlanetX
    sta $D000
    clc
    adc #8
    sta $D001
    adc #8
    sta $D002
    adc #8
    sta $D003
    ldx #0
ShadeLine
    sta $D40A             ; synchronize the grey ramps to each scanline
    lda $3800,x
    sta $D012
    lda $3840,x
    sta $D013
    lda $3880,x
    sta $D014
    lda $38C0,x
    sta $D015
    inx
    cpx #56
    bne ShadeLine
    sta $D40A
    lda #1
    sta $D009             ; restore double-width comet below planet band
    ldx #3
RestoreGreys
    lda $02C0,x
    sta $D012,x
    dex
    bpl RestoreGreys
    jsr Position          ; restore independent comet/star coordinates
    pla
    tax
    pla
    rti
Clock dta 0
FarX dta 190
MidX dta 182
PlanetX dta 142
StarX dta 78,110,155,190
StartX dta 78,110,155,190
RateMask dta 7,1,3,7
    ert * > $4400
