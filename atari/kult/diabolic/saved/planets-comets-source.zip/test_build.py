#!/usr/bin/env python3
import sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from build import project,kult,word
from py65.devices.mpu6502 import MPU

class NativeSpaceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original=project('kult')['banks']['ram']
        cls.ram=kult((ROOT/'kult-diabolic.xex').read_bytes())[0]
    def cpu(self):return MPU(memory=list(self.ram))
    def call(self,c,pc,stop=0x200):
        c.pc=pc;c.stPushWord(stop-1)
        for _ in range(100000):
            if c.pc==stop:return
            c.step()
        self.fail(f'CPU did not return from {pc:04x}')
    def test_only_intended_ranges_changed(self):
        allowed=[(0x2400,0x4400),(0x6a84,0x6f84),(0xf746,0xf749),(0xf834,0xf837),(0xc41b,0xc41e),(0xe843,0xe846),(0xf75f,0xf760),(0xf764,0xf765),(0xf769,0xf76a),(0xf975,0xf977)]
        loaded=set()
        for block in project('kult')['blocks']:
            if block['start'] not in (0xd301,0xbb00):loaded.update(range(block['start'],block['start']+block['size']))
        for a in loaded:
            old,new=self.original[a],self.ram[a]
            if old!=new:self.assertTrue(any(lo<=a<hi for lo,hi in allowed),hex(a))
    def test_ship_alignments(self):
        for frame in range(4):
            base=word(self.ram,0x7450+frame*2);src=self.ram[base:base+80]
            self.assertNotEqual(src,self.original[base:base+80])
            for shift in range(4):
                expected=b''.join((int.from_bytes(src[y*5:y*5+5],'big')>>(shift*2)).to_bytes(5,'big') for y in range(16))
                self.assertEqual(expected,self.ram[base+shift*80:base+(shift+1)*80])
    def test_background_cannot_hit_ship_but_enemies_can(self):
        for pixel,expected in [(0,0),(0x55,0),(0xaa,3),(0xff,3)]:
            c=self.cpu();c.memory[0xef74]=0x60;c.memory[0xfa]=0;c.memory[0xfb]=0x78
            c.memory[0x7800:0x7850]=[pixel]*80;c.memory[0xf398]=0
            self.call(c,0xf953);self.assertEqual(c.memory[0xf398],expected)
        # Every enemy frame still has solid pixels after reserving colour 01.
        for frame in range(128):self.assertTrue(any(v&0xaa for v in self.ram[0x4f80+frame*32:0x4fa0+frame*32]))
    def test_parallax_and_menu_cleanup(self):
        c=self.cpu();c.memory[0xe9d6]=0x60;self.call(c,0x4000)
        initial=c.memory[0xd000:0xd004]
        stars=c.memory[0xd004:0xd008]
        for _ in range(16):self.call(c,0x4003,0xf908)
        self.assertEqual(c.memory[0xd000:0xd004],[initial[0]-4,initial[1]-16,initial[2]-1,initial[3]-1])
        self.assertEqual(c.memory[0xd004:0xd008],[stars[0]-2,stars[1]-8,stars[2]-4,stars[3]-2])
        self.call(c,0x4006);self.assertEqual(c.memory[0xd01d],0)
        self.assertEqual(c.memory[0xd000:0xd008],[0]*8)
    def test_raster_shading_restores_game_registers(self):
        c=self.cpu();c.memory[0xe9d6]=0x60;self.call(c,0x4000)
        positions=c.memory[0xd000:0xd008]
        c.a=0x91;c.x=0x37;c.y=0x5b;c.memory[0xd40b]=33
        c.stPushWord(0x200);c.stPush(c.p);c.pc=0x400c
        shades=[]
        for _ in range(10000):
            if c.pc==0x200:break
            if c.memory[c.pc:c.pc+3]==[0x8d,0x12,0xd0]:shades.append(c.a)
            c.step()
        else:self.fail('Planet raster did not return from interrupt')
        self.assertEqual((c.a,c.x,c.y),(0x91,0x37,0x5b))
        self.assertEqual(len(shades),56)
        self.assertGreaterEqual(len(set(shades)),3)
        self.assertEqual(c.memory[0xd012:0xd016],c.memory[0x2c0:0x2c4])
        self.assertEqual(c.memory[0xd000:0xd008],positions)
        self.assertEqual(c.memory[0xd009],1)
        self.assertEqual((c.memory[0x606d],c.memory[0x622f]),(0xdf,0xdf))
        # Original bottom-of-frame DLI still runs, without the planet loop.
        c.pc=0x400c;c.a=0x91;c.memory[0xd40b]=100
        for _ in range(30):
            if c.pc==0xea73:break
            c.step()
        self.assertEqual((c.pc,c.a),(0xea73,0x91))

    def test_all_tile_choices_stay_in_star_bank(self):
        c=self.cpu()
        for section in range(32):
            c.memory[0x4e79]=section
            for column in range(16):
                c.memory[0x4e7a]=column
                for row in range(8):
                    c.y=row;self.call(c,0x4009)
                    p=word(c.memory,0x80)
                    self.assertTrue(0x2400<=p<0x2600)
                    self.assertEqual(c.y,row)
                    self.assertTrue(all(v&0xaa==0 for v in self.ram[p:p+32]))
if __name__=='__main__':unittest.main()
