# Kult: Diabolic — native Atari edition

A playable modification of the original Kult XEX for a standard PAL Atari
800XL with 64 KB. The helicopter is replaced by an animated, horned spaceship;
buildings are replaced by open space. Kult's original monochrome playfield
colours, enemies, waves, weapons, menus, score display and sound code remain.

The scrolling playfield supplies the nearest stars. Five hardware star groups
(one player and four missiles) spread the distant stars across the sky, moving
at three slower rates. A bright comet with a split tail crosses faster than
these distant layers. During the planet’s scanlines, all four hardware players are temporarily
combined at normal width to draw Saturn with 32 horizontal samples (previously
16 stretched samples) across the same 64 hires-pixel width. Per-scanline
luminance ramps supply six grey shades, with finer double rings, cloud bands
and a dithered day/night boundary. Afterwards the renderer restores the
independent star and comet positions. Saturn drifts most slowly, and all
scenery retains the original monochrome palette. `scenery.png` previews the new native art.

This is a hardware-appropriate parallax effect, not the browser's translucent
nebula renderer. Background star pixels are excluded from the software collision
test; hardware stars, Saturn and the comet are decorative and harmless. Enemy
pixels retain collision. No VBXE is needed.

Run from WSL:

```sh
/home/marcin/tmp/pico/atari/kult/diabolic/run-emulator.sh
```

The launcher uses the same isolated standard-game Altirra configuration as
Babajaga and Speed. Arrow keys move; left Ctrl is joystick fire and advances
the original title/stage screens. The original `Kult (v1).xex` is untouched.

Rebuild and check:

```sh
cd /home/marcin/tmp/pico/atari/kult/diabolic
./build.sh
python3 test_build.py
```

Requires Python 3, Pillow, py65 and MADS. `build.py` generates all four ship
frames and their four horizontal alignments, star tiles, hardware scenery and
the executable. `space.asm` contains the 6502 initialization, movement and menu
cleanup hooks. The extension and PM graphics reuse the retired building bank.

Packaging preserves a literal prefix in that bank because overcompressing the
new empty space would let Kult's in-place loader overwrite its unread input.
Every loaded runtime block is checked by replaying the original 6502 depacker.
The tests also check allowed patch ranges, sprite alignments, harmless stars,
solid enemy pixels, tile addressing, separate layer speeds, raster shading and register restoration, and menu cleanup.

`verify-emulator.ps1` boots the XEX in Altirra and records native screenshots
and a debugger log in `verification/`. It changes two menu instructions only
in emulator RAM to advance the fire prompts automatically; those changes are
not included in the distributed XEX. This is a boot/gameplay smoke test, not
an automated full-game completion test.
